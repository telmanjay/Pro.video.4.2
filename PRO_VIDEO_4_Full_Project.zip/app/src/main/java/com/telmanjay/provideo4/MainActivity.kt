package com.telmanjay.provideo4

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Surface
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var manager: CameraManager
    private val executor = Executor { it.run() }
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private val recorders = mutableListOf<MediaRecorder>()
    private val surfaces = mutableListOf<Surface>()
    private val files = mutableListOf<File>()
    private var logicalId: String? = null
    private var physicalIds: List<String> = emptyList()
    private var recording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(CAMERA_SERVICE) as CameraManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(9,10,16))
        }
        fun label(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); setPadding(0,8,0,8)
        }
        root.addView(label("PRO VIDEO 4", 30f, Color.rgb(205,187,255)))
        root.addView(label("MULTI-CAMERA VIDEO LAB", 13f, Color.LTGRAY))
        root.addView(label("Прототип. Поддержка четырёх потоков зависит от Camera2 и прошивки OPPO. Цветовые пресеты пока не применяются к видео.", 14f))
        info = label("Проверка камер…", 12f, Color.LTGRAY)
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(info)
        inner.addView(Button(this).apply { text = "ПОВТОРИТЬ ПРОВЕРКУ"; setOnClickListener { inspect() } })
        inner.addView(Button(this).apply { text = "НАЧАТЬ ЗАПИСЬ 4 КАМЕР"; setOnClickListener { startRecording() } })
        inner.addView(Button(this).apply { text = "ОСТАНОВИТЬ"; setOnClickListener { stopRecording() } })
        inner.addView(label("Тестовая конфигурация: 4 отдельных файла MP4, 1080p/30, H.264/AAC. Это не максимальное качество сенсора. Файлы сохраняются в Movies/PRO_VIDEO_4 внутри хранилища приложения.", 13f, Color.rgb(255,207,140)))
        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 10)
        } else inspect()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 10 && results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) inspect()
    }

    private fun inspect() {
        val out = StringBuilder()
        logicalId = null; physicalIds = emptyList()
        try {
            out.append("Одновременные camera ID, разрешённые системой:\n")
            if (Build.VERSION.SDK_INT >= 30) out.append(manager.concurrentCameraIds.joinToString("\n") { it.joinToString(prefix="{", postfix="}") })
            else out.append("API ниже 30")
            out.append("\n\n")
            for (id in manager.cameraIdList) {
                val c = manager.getCameraCharacteristics(id)
                val back = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                val phys = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.toList() else emptyList()
                val sizes = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    ?.getOutputSizes(MediaRecorder::class.java)?.sortedByDescending { it.width * it.height }?.take(4)
                out.append("ID $id ${if(back) "ЗАДНЯЯ" else "не задняя"}\n")
                out.append("Physical IDs: ${phys.joinToString().ifBlank { "нет" }}\n")
                out.append("Recorder sizes: ${sizes?.joinToString { "${it.width}x${it.height}" } ?: "нет"}\n\n")
                if (back && phys.size >= 4 && logicalId == null) { logicalId = id; physicalIds = phys.take(4) }
            }
            out.append(if (physicalIds.size >= 4) "\nОбнаружены 4 physical ID, но успешная запись ещё не подтверждена." else "\nПубличный Camera2 API не показал четыре физических ID в одном логическом модуле.")
        } catch (e: Exception) { out.append("\nОшибка: ${e.javaClass.simpleName}: ${e.message}") }
        info.text = out.toString()
    }

    private fun startRecording() {
        if (recording) return
        val id = logicalId
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Разреши камеру и микрофон", Toast.LENGTH_LONG).show(); return
        }
        if (id == null || physicalIds.size < 4) {
            Toast.makeText(this, "Четыре физических ID не обнаружены. Смотри отчёт.", Toast.LENGTH_LONG).show(); return
        }
        try {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "PRO_VIDEO_4")
            dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            repeat(4) { i ->
                val f = File(dir, "PRO_VIDEO_4_${stamp}_CAM${i+1}.mp4")
                val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
                r.setAudioSource(MediaRecorder.AudioSource.MIC)
                r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setOutputFile(f.absolutePath)
                r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setVideoSize(1920,1080); r.setVideoFrameRate(30); r.setVideoEncodingBitRate(16_000_000)
                r.prepare()
                recorders.add(r); surfaces.add(r.surface); files.add(f)
            }
            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    try {
                        val outs = surfaces.mapIndexed { i, s -> OutputConfiguration(s).apply { setPhysicalCameraId(physicalIds[i]) } }
                        camera.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outs, executor,
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(s: CameraCaptureSession) {
                                    session = s
                                    try {
                                        val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                                        surfaces.forEach { req.addTarget(it) }
                                        s.setRepeatingRequest(req.build(), null, null)
                                        recorders.forEach { it.start() }
                                        recording = true
                                        runOnUiThread { info.text = "Запись запущена. Проверь четыре MP4-файла и их синхронность." }
                                    } catch (e: Exception) { fail("Старт записи не удался: ${e.message}") }
                                }
                                override fun onConfigureFailed(s: CameraCaptureSession) { fail("Прошивка отказала в создании сессии четырёх камер.") }
                            }))
                    } catch (e: Exception) { fail("Сессия не поддерживается: ${e.message}") }
                }
                override fun onDisconnected(camera: CameraDevice) { fail("Камера отключена"); camera.close() }
                override fun onError(camera: CameraDevice, error: Int) { fail("Ошибка камеры $error"); camera.close() }
            }, null)
        } catch (e: Exception) { cleanup(); info.text = "Не удалось подготовить потоки: ${e.message}" }
    }

    private fun fail(msg: String) { runOnUiThread { info.text = msg; Toast.makeText(this,msg,Toast.LENGTH_LONG).show() }; stopRecording() }
    private fun stopRecording() {
        try { session?.stopRepeating() } catch (_: Exception) {}
        try { session?.close() } catch (_: Exception) {}
        session = null
        recorders.forEach { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        recorders.clear(); surfaces.clear()
        try { device?.close() } catch (_: Exception) {}
        device = null; recording = false
        if (files.isNotEmpty()) info.text = "Остановлено. Выходные файлы:\n" + files.joinToString("\n") { it.absolutePath }
    }
    private fun cleanup() {
        recorders.forEach { try { it.release() } catch (_: Exception) {} }
        recorders.clear(); surfaces.clear()
        try { device?.close() } catch (_: Exception) {}
        device = null
    }
    override fun onDestroy() { stopRecording(); super.onDestroy() }
}
