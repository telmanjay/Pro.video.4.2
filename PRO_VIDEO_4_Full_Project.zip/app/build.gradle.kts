plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.telmanjay.provideo4"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.telmanjay.provideo4"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
