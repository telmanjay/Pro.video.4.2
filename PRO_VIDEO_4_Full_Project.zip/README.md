# PRO VIDEO 4 prototype

Best-effort Camera2 prototype for OPPO Find X7 Ultra.

- Attempts four MediaRecorder outputs routed to physical camera IDs exposed by a logical rear camera.
- Android/OEM firmware may reject this configuration; four simultaneous streams are not guaranteed.
- Initial recording configuration is 1080p/30 H.264/AAC per stream for feasibility, not maximum sensor quality.
- Professional color presets are not implemented in this prototype.
- Debug APK is unsigned and intended for device testing.
- Four streams can overheat the phone, drain battery, or exceed encoder/session limits.

Build: upload all files and folders preserving this structure to repository root, then run Actions > Build PRO VIDEO 4 APK. Download artifact PRO-VIDEO-4-debug-apk and extract app-debug.apk.
