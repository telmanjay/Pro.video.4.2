package com.provideo4

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val lime = Color.rgb(182, 255, 74)
    private val bg = Color.rgb(8, 9, 11)
    private val panel = Color.rgb(21, 23, 27)
    private val white = Color.rgb(244, 245, 247)
    private val muted = Color.rgb(163, 168, 178)
    private lateinit var output: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 40)
        } else {
            inspectCameras()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                inspectCameras()
            } else {
                output.text = "Доступ к камере не разрешён. Разреши его в настройках приложения и нажми «ПОВТОРИТЬ ПРОВЕРКУ»."
            }
        }
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(bg)
        }
        base.addView(TextView(this).apply {
            text = "PRO VIDEO 4"
            textSize = 27f
            setTextColor(lime)
            letterSpacing = 0.08f
        })
        base.addView(TextView(this).apply {
            text = "MULTI-CAMERA DIAGNOSTICS"
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(muted)
            setPadding(0, 4, 0, 22)
        })
        base.addView(TextView(this).apply {
            text = "Проверка возможностей камеры"
            textSize = 18f
            setTextColor(white)
            setPadding(0, 0, 0, 8)
        })
        base.addView(TextView(this).apply {
            text = "Проверяем не только список объективов, но и комбинации камер, которые Android официально разрешает запускать одновременно. Это всё ещё диагностика: реальная запись четырёх потоков должна быть проверена отдельным тестом на устройстве."
            textSize = 13f
            setTextColor(muted)
            setPadding(0, 0, 0, 18)
        })
        base.addView(Button(this).apply {
            text = "ПОВТОРИТЬ ПРОВЕРКУ"
            setTextColor(bg)
            setBackgroundColor(lime)
            setOnClickListener { inspectCameras() }
        }, LinearLayout.LayoutParams(-1, -2))

        output = TextView(this).apply {
            textSize = 13f
            setTextColor(white)
            setTextIsSelectable(true)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(panel)
        }
        val scroll = ScrollView(this).apply {
            setPadding(0, 18, 0, 0)
            addView(output)
        }
        base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(base)
    }

    private fun inspectCameras() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            output.text = "Нужно разрешить доступ к камере и нажать «Повторить проверку»."
            return
        }
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager
        val lines = mutableListOf<String>()
        val ids = try { manager.cameraIdList.toList() } catch (e: Exception) {
            output.text = "Не удалось получить список камер: ${e.javaClass.simpleName}: ${e.message}"
            return
        }

        lines += "УСТРОЙСТВО"
        lines += "${Build.MANUFACTURER} ${Build.MODEL}"
        lines += "Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}"
        lines += ""
        lines += "ОБНАРУЖЕННЫЕ CAMERA ID: ${ids.size}"
        lines += "────────────────────────"

        var logicalCount = 0
        val physicalIdsInLogicalGroups = linkedSetOf<String>()
        val rearIds = mutableListOf<String>()

        ids.forEachIndexed { index, id ->
            try {
                val c = manager.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_BACK -> "Задняя"
                    CameraCharacteristics.LENS_FACING_FRONT -> "Передняя"
                    CameraCharacteristics.LENS_FACING_EXTERNAL -> "Внешняя"
                    else -> "Неизвестно"
                }
                if (facing == "Задняя") rearIds += id
                val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                val logical = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
                val physical = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds else emptySet()
                if (logical) {
                    logicalCount++
                    physicalIdsInLogicalGroups.addAll(physical)
                }
                val map: StreamConfigurationMap? = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val recorderSizes = map?.getOutputSizes(MediaRecorder::class.java)
                val largest = recorderSizes?.maxByOrNull { it.width.toLong() * it.height }
                    ?.let { "${it.width}×${it.height}" } ?: "не определено"
                val fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    ?.joinToString { "${it.lower}–${it.upper}" } ?: "нет данных"

                lines += "${index + 1}. ID $id — $facing"
                lines += "   Logical multi-camera: ${if (logical) "ДА" else "нет"}"
                lines += "   Physical IDs: ${if (physical.isEmpty()) "не опубликованы" else physical.joinToString()}"
                lines += "   Макс. размер MediaRecorder: $largest"
                lines += "   Диапазоны AE FPS: $fpsRanges"
                lines += ""
            } catch (e: Exception) {
                lines += "ID $id: ошибка чтения (${e.javaClass.simpleName}: ${e.message})"
                lines += ""
            }
        }

        lines += "ОДНОВРЕМЕННАЯ РАБОТА КАМЕР"
        lines += "────────────────────────"
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val concurrentSets = manager.concurrentCameraIds
                if (concurrentSets.isEmpty()) {
                    lines += "Android не объявляет ни одной поддерживаемой комбинации concurrent cameras."
                    lines += "Это не подтверждает поддержку четырёх камер одновременно."
                } else {
                    lines += "Комбинации, объявленные системой: ${concurrentSets.size}"
                    concurrentSets.forEachIndexed { i, set ->
                        lines += "Набор ${i + 1}: ${set.joinToString()}"
                        lines += "   Количество ID в наборе: ${set.size}"
                    }
                    val maxSimultaneousIds = concurrentSets.maxOfOrNull { it.size } ?: 0
                    lines += "Максимум ID в одном наборе: $maxSimultaneousIds"
                    lines += if (maxSimultaneousIds >= 4) {
                        "Предварительный вывод: система объявляет набор из 4+ camera ID. Требуется тест открытия сессии и записи."
                    } else {
                        "Предварительный вывод: опубликованные наборы не подтверждают 4 одновременных camera ID."
                    }
                }
            } catch (e: Exception) {
                lines += "Ошибка чтения concurrentCameraIds: ${e.javaClass.simpleName}: ${e.message}"
            }
        } else {
            lines += "API concurrent camera sets доступен начиная с Android 11 (API 30)."
        }
        lines += ""
        lines += "СВОДКА"
        lines += "Camera ID всего: ${ids.size}"
        lines += "Задних camera ID: ${rearIds.size} (${rearIds.joinToString().ifBlank { "нет" }})"
        lines += "Логических multi-camera ID: $logicalCount"
        lines += "Физических ID внутри логических групп: ${physicalIdsInLogicalGroups.size}"
        lines += ""
        lines += "ВАЖНО"
        lines += "Даже набор из четырёх ID в concurrentCameraIds не гарантирует четыре независимых видеозаписи. Далее нужно создать CameraCaptureSession с подходящими выходами, проверить поддерживаемые размеры/частоту кадров и провести длительную запись с контролем нагрева, пропусков кадров и синхронизации."
        lines += ""
        lines += "Отчёт можно выделить и скопировать: нажми и удерживай текст."
        output.text = lines.joinToString("\n")
    }
}
