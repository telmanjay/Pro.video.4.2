plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.provideo4"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.provideo4"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-diagnostic"
    }
}
