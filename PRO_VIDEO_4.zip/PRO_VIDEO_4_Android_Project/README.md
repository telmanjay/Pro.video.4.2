# PRO VIDEO 4 — Android Studio diagnostic build

This iteration adds Android's `CameraManager.concurrentCameraIds` inspection (API 30+) to the existing Camera2 device report.

## What this version does
- Requests camera permission.
- Lists available camera IDs and rear-facing IDs.
- Reports logical multi-camera capabilities and physical IDs exposed by the device.
- Reports the largest advertised MediaRecorder output size and AE target FPS ranges.
- Lists system-declared concurrent camera ID sets where supported.
- Clearly distinguishes advertised concurrency from verified four-stream recording.

## Build a debug APK
1. Open this folder in a recent Android Studio version.
2. Let Gradle sync and install the Android SDK components if prompted.
3. Connect OPPO Find X7 Ultra with USB debugging enabled.
4. Run the `app` configuration, grant camera permission, and press **ПОВТОРИТЬ ПРОВЕРКУ**.
5. Copy or screenshot the full report and send it back.

To build: **Build > Build APK(s)**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Current limitations
This is still a diagnostic prototype, not the final recorder. It does not yet capture or save video. The report's concurrent ID sets are a useful first gate, but actual support must be tested by opening a session with four suitable outputs and recording while monitoring frame drops, thermal throttling, storage throughput, and timestamp alignment.

The current build environment used to prepare this source does not have Android SDK/Gradle installed, so an APK could not be compiled or device-tested here.
