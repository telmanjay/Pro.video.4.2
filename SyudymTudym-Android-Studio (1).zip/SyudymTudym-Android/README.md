# СюдымТудым — Android Studio project

Это проект для сборки APK, не готовый APK.

## Сборка
1. Установите Android Studio: https://developer.android.com/studio
2. Распакуйте архив.
3. В Android Studio выберите **Open** и укажите папку `SyudymTudym-Android`.
4. Дождитесь Gradle Sync. Установите предложенные Android SDK компоненты, если потребуется.
5. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Проект содержит Android WebView-оболочку и встроенный веб-интерфейс. Сетевые возможности и WebRTC необходимо проверить на реальных устройствах. Это не подтверждает готовность приложения к публичному выпуску: автоматический поиск по логину без сигнализации не обеспечивается.
